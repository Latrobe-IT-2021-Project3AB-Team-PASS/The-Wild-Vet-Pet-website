<?php
	include_once 'header.php';

?>
<title>MY PETS/title></title>

	<h1>MY PETS</h1>

<style>
th, td {
  border-bottom: 1px solid #ddd;
}
</style>
<body>
<section style="text-align:center">
<h2>My Pets Infomation</h2>

<table style="width:100%">
  <tr>
    <th>Pet Name</th>
    <th>Pet Type</th>
    <th>Pet Sex</th>
     <th>Pet BOD</th>
     <th>Pet Desexed</th>
     <th>Pet notes</th>
  </tr>
  <tr>
    <td>Juhua</td>
    <td>Cat</td>
    <td>Male</td>
    <td>2020-01-01</td>
    <td>Yes</td>
    <td>No allergies</td>
  </tr>
  <tr>
    <td>Dingding</td>
    <td>Cat</td>
    <td>Female</td>
    <td>2021-06-01</td>
    <td>Yes</td>
    <td>No allergies</td>
  </tr>
</table>
</section>
</body>

