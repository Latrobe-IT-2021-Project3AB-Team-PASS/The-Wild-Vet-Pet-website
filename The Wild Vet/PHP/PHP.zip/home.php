<?php
	include_once 'header.php';
?>

<title>HOME</title>
<h1>HOME</h1>
<h2>ONE VET<br>FOR<br>ALL PETS</h2>

<section>
	<div class="slidershow middle">

	   	<div class="slides">
	        <input type="radio" name="r" id="r1" checked>
	        <input type="radio" name="r" id="r2">
	        <input type="radio" name="r" id="r3">

	        <div class="slide s1">
	          	<img src="img/1.jpg" alt="">
	        </div>
	        
	        <div class="slide">
	          	<img src="img/2.jpg" alt="">
	        </div>
	        
	        <div class="slide">
	          	<img src="img/3.jpg" alt="">
	        </div>
	    </div>

	    <div class="navigation">
	        <label for="r1" class="bar"></label>
	        <label for="r2" class="bar"></label>
	        <label for="r3" class="bar"></label>
      	</div>
    </div>
</section>
